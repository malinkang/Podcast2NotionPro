from podcast2notion.podcast import main

if __name__ == "__main__":
    main()
